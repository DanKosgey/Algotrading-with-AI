import os

# Ensure the environment variable is set correctly
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'  # Set to disable oneDNN custom operations

# Now, proceed with importing TensorFlow and other necessary modules
import tensorflow as tf
import asyncio
import logging
import json
from intface import MT5Interface
from modl import LSTMModel
from statte import TradingStrategy
from retraining import ModelRetrainer
from risk_management import RiskManagement
from place_order import PlaceOrder
from feature_engineering import FeatureEngineering
import MetaTrader5 as MT5
from features import Indicators
import errno

def load_config(config_path=r'C:\Users\HP\Desktop\machine learning\logins.json'):
    try:
        with open(config_path, 'r') as file:
            config = json.load(file)
        return config
    except FileNotFoundError:
        logging.error("Config file not found.")
        return None
    except json.JSONDecodeError:
        logging.error("Error decoding JSON config file.")
        return None

def setup_logging(log_path):
    log_dir = os.path.dirname(log_path)
    
    if not os.path.exists(log_dir):
        try:
            os.makedirs(log_dir)
        except OSError as exc:
            if exc.errno != errno.EEXIST:
                raise

    logger = logging.getLogger()
    
    if not logger.hasHandlers():
        logger.setLevel(logging.INFO)
        
        file_handler = logging.FileHandler(log_path)
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        logger.addHandler(file_handler)
        
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        logger.addHandler(console_handler)

async def main():
    config = load_config()
    if not config:
        logging.error("Failed to load configuration.")
        return
    
    setup_logging(config['log_path'])
    mt5 = MT5Interface(config)
    if not mt5.connect():
        logging.error("Failed to connect to MetaTrader 5")
        return
    
    symbols = config['symbols']  # Ensure it's a list
    if isinstance(symbols, str):
        symbols = [symbols]  # Convert to list if it's a single string
    
    symbol=symbols[0]
    df = mt5.get_latest_data(symbol, MT5.TIMEFRAME_H4, count=300)
    if df is None or df.empty:
        logging.error("Failed to fetch initial data from MT5")
        return
    indicators = Indicators(df)
    df = indicators.calculate_indicators(df)
    fe = FeatureEngineering(df)
    df_with_changes = fe.calculate_changes(df)
    if df_with_changes is None or df_with_changes.empty:
        logging.error("Invalid DataFrame passed to FeatureEngineering")
        return
    timesteps =15
    num_features = df_with_changes.shape[1]
    model = LSTMModel()
    model.create_model((timesteps, num_features))
    logging.info("Model created successfully")

    df_with_changes.to_csv('model_training.csv', index=False)
    logging.info("DataFrame saved as 'model_training.csv'")
    
    retrainer = ModelRetrainer(model, mt5, config, None)
    logging.info("Training the model for the first time...")
    
    retrainer.retrain_and_save_model(df_with_changes,timesteps)
    model.load_model(config['model_path'])
    logging.info(f"Model loaded successfully from {config['model_path']}")
    
    risk_manager = RiskManagement()
    place_order = PlaceOrder(symbol)  # Initialize the PlaceOrder class with the symbol

    async def retrain_model_periodically():
        while True:
            await asyncio.sleep(3600)
            logging.info("Retraining model with new data...")
            df = mt5.get_latest_data(symbol, MT5.TIMEFRAME_H4, count=300)
            if df is None or df.empty:
                logging.error("Failed to fetch new data from MT5, trying to reconnect...")
                mt5.reconnect()
                df = mt5.get_latest_data(symbol, MT5.TIMEFRAME_H4, count=300)
                if df is None or df.empty:
                    logging.error("Failed to fetch new data from MT5 after reconnecting")
                    continue
            indicators = Indicators(df)
            df = indicators.calculate_indicators(df)
            fe = FeatureEngineering(df)
            df_with_changes = fe.calculate_changes(df)
            if df_with_changes is None or df_with_changes.empty:
                logging.error("Invalid DataFrame passed to FeatureEngineering")
                continue
            df_with_changes.to_csv('model_training.csv', index=False)
            logging.info("Updated 'model_training.csv'")
            retrainer.retrain_and_save_model(df_with_changes,timesteps)
            model.load_model(config['model_path'])
            logging.info(f"Model reloaded after retraining from {config['model_path']}")

    asyncio.create_task(retrain_model_periodically())

    strategy = TradingStrategy(model, symbol, df_with_changes, config)

    try:
        while True:
            df = mt5.get_latest_data(symbol, MT5.TIMEFRAME_H4, count=300)
            if df is None or df.empty:
                logging.error("Failed to fetch new data from MT5, trying to reconnect...")
                mt5.reconnect()
                df = mt5.get_latest_data(symbol, MT5.TIMEFRAME_H4, count=300)
                if df is None or df.empty:
                    logging.error("Failed to fetch new data from MT5 after reconnecting")
                    continue
            indicators = Indicators(df)
            df = indicators.calculate_indicators(df)
            fe = FeatureEngineering(df)
            df_with_changes = fe.calculate_changes(df)
            if df_with_changes is None or df_with_changes.empty:
                logging.error("Invalid DataFrame passed to FeatureEngineering")
                continue
            df_with_changes.to_csv('model_prediction.csv', index=False)            
            if not df_with_changes.empty:
                signal = strategy.generate_signal(timesteps,df_with_changes)

                # Execute trade based on signal
                place_order.execute_trade(signal)
                # Calculate and log risk
                risk_percentage = place_order.calculate_risk()
                logging.info(f"Current risk percentage: {risk_percentage}")
                
                num_features = len([col for col in df_with_changes.columns])
                X_test = df_with_changes[[col for col in df_with_changes.columns]].values[-15:].reshape((1, 15, num_features))
                y_test = df_with_changes['close_change'].values[-1:].reshape((1, 1))
                
                rmse = model.evaluate(X_test, y_test)
                logging.info(f"RMSE: {rmse}")
                
                risk_manager.manage_account()
                                
                logging.info("Continuing trading loop...")
            await asyncio.sleep(config['update_interval'])
    except KeyboardInterrupt:
        logging.info("Shutting down the trading bot...")
    finally:
        mt5.shutdown()

if __name__ == "__main__":
    asyncio.run(main())
