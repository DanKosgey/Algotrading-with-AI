import pandas as pd
import logging
import MetaTrader5 as mt5
from trend import Trend  # Import the Trend class

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def fetch_data(symbol: str, num_bars: int):
    """Fetch historical data for the given symbol."""
    if not mt5.initialize():
        logging.error("Failed to initialize MT5")
        return pd.DataFrame()

    rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M15, 0, num_bars)
    if rates is None or len(rates) == 0:
        logging.error(f"Failed to fetch data for {symbol}")
        return pd.DataFrame()

    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s')
    return df

def main():
    symbol = 'EURUSD'  # Change this to your desired symbol
    num_bars = 500  # Number of bars to fetch for analysis

    # Fetch historical data
    df = fetch_data(symbol, num_bars)
    if df.empty:
        logging.error("No data fetched")
        return

    # Initialize Trend class and calculate trend predictions
    trend = Trend(df)
    df['Trend_Prediction'] = [trend.get_trend(symbol) for _ in range(len(df))]
    
    # Save to CSV for visualization
    df[['time', 'close', 'Trend_Prediction']].to_csv('trend.csv', index=False)
    logging.info("Trend predictions saved to trend.csv")

if __name__ == "__main__":
    main()
