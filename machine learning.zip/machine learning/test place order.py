import MetaTrader5 as mt5
import logging
import json

# Load configuration from JSON file
with open(r'C:\Users\user\Desktop\python\working bot\logins.json', 'r') as file:
    config = json.load(file)

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def initialize_mt5():
    if not mt5.initialize(path=config['mt5Pathway']):
        logging.error("Failed to initialize MT5")
        return False
    if not mt5.login(login=config['username'], password=config['password'], server=config['server']):
        logging.error("Failed to log in to MT5")
        return False
    logging.info("MT5 initialized and logged in")
    return True

def place_order(order_type, symbol, volume, comment):
    if not initialize_mt5():
        logging.error("MT5 not initialized or logged in")
        return None
    
    # Fetch current market prices
    symbol_info_tick = mt5.symbol_info_tick(symbol)
    if not symbol_info_tick:
        logging.error(f"Failed to get current price for {symbol}")
        return None
    
    if order_type == "SELL_STOP":
        order_type_mt5 = mt5.ORDER_TYPE_SELL_STOP
        price = round(symbol_info_tick.bid - 0.0001, 5)  # Example: slightly below the current bid
        stop_loss = round(price + 0.001, 5)  # SL above the order price
        take_profit = round(price - 0.001, 5)  # TP below the order price
    elif order_type == "BUY_STOP":
        order_type_mt5 = mt5.ORDER_TYPE_BUY_STOP
        price = round(symbol_info_tick.ask + 0.0001, 5)  # Example: slightly above the current ask
        stop_loss = round(price - 0.001, 5)  # SL below the order price
        take_profit = round(price + 0.001, 5)  # TP above the order price

    request = {      
        "action": mt5.TRADE_ACTION_PENDING,
        "symbol": symbol,
        "volume": volume,
        "type": order_type_mt5,
        "price": price,
        "sl": stop_loss,
        "tp": take_profit,
        "type_filling": mt5.ORDER_FILLING_RETURN,
        "type_time": mt5.ORDER_TIME_GTC,
        "comment": comment
    }
    
    order_result = mt5.order_send(request)
    
    if order_result is None:
        logging.error("Order send failed: result is None")
        return None
    elif order_result.retcode != mt5.TRADE_RETCODE_DONE:
        logging.error(f"Failed to place order, error code: {order_result.retcode}")
        return order_result
    else:
        logging.info(f"Order for {symbol} successful")
        return order_result

# Example usage with current market prices
order_type = "SELL_STOP"
symbol = "EURUSD"
volume = 0.01  # Adjusted to meet minimum lot size requirement
comment = "Automated trade"

result = place_order(order_type, symbol, volume, comment)
if result:
    print(result)

# Check the minimum lot size for the symbol programmatically
def check_minimum_lot_size(symbol):
    if not initialize_mt5():
        logging.error("MT5 not initialized or logged in")
        return None
    
    symbol_info = mt5.symbol_info(symbol)
    if symbol_info is not None:
        print(f"Minimum volume for {symbol}: {symbol_info.volume_min}")
        print(f"Volume step for {symbol}: {symbol_info.volume_step}")
    else:
        logging.error(f"Failed to get symbol info for {symbol}")
    
    mt5.shutdown()

# Example check for minimum lot size
check_minimum_lot_size("EURUSD")
