# Importing necessary libraries for scaling, neural network, and model persistence
from sklearn.preprocessing import MinMaxScaler  # Used to scale data to a specific range (0-1)
from tensorflow.keras.callbacks import ReduceLROnPlateau  # Used to adjust the learning rate during training
import joblib  # For saving and loading models and scalers
import logging  # For logging errors and information
import numpy as np  # For numerical computations, especially for calculating RMSE
from tensorflow.keras.models import load_model  # For loading pre-trained models


class LSTMModel:
    """
    A class to define and handle an LSTM-based model for time-series prediction.
    This class includes methods for creating, training, predicting, saving, and loading an LSTM model.
    """
    
    def __init__(self, lstm_units=50, optimizer='adam', loss='mean_squared_error', dropout_rate=0.2):
        """
        Initializes the LSTMModel object with the given parameters.
        
        :param lstm_units: Number of units in each LSTM layer.
        :param optimizer: The optimizer to be used for training (e.g., 'adam').
        :param loss: The loss function for training (default: 'mean_squared_error').
        :param dropout_rate: Dropout rate used to prevent overfitting (default: 0.2).
        """
        self.lstm_units = lstm_units  # Number of units in each LSTM layer
        self.optimizer = optimizer  # Optimizer for the model
        self.loss = loss  # Loss function
        self.dropout_rate = dropout_rate  # Dropout rate to avoid overfitting
        self.model = None  # Initialize model as None (will be created later)
        self.scaler = MinMaxScaler(feature_range=(0, 1))  # Scaler to normalize input features to range 0-1
        self.output_scaler = MinMaxScaler(feature_range=(0, 1))  # Scaler for the output values (predictions)

    def create_model(self, input_shape):
        """
        Creates and compiles the LSTM model using the provided input shape.
        
        :param input_shape: Shape of the input data (number of timesteps and features).
        """
        from tensorflow.keras.models import Sequential  # Sequential model for stacking layers
        from tensorflow.keras.layers import LSTM, Dropout, Dense, Input, Bidirectional  # Layers for the LSTM architecture
        
        # Building the model architecture
        self.model = Sequential([
            Input(shape=input_shape),  # Input layer with the shape of the data
            Bidirectional(LSTM(units=self.lstm_units, return_sequences=True)),  # First LSTM layer (Bidirectional)
            Dropout(self.dropout_rate),  # Dropout to prevent overfitting
            Bidirectional(LSTM(units=self.lstm_units, return_sequences=True)),  # Second LSTM layer (Bidirectional)
            Dropout(self.dropout_rate),  # Dropout to prevent overfitting
            LSTM(units=self.lstm_units),  # Third LSTM layer (Single direction)
            Dropout(self.dropout_rate),  # Dropout to prevent overfitting
            Dense(units=1)  # Output layer with a single unit (for regression)
        ])
        
        # Compile the model with the specified optimizer and loss function
        self.model.compile(optimizer=self.optimizer, loss=self.loss)

    def train(self, X_train, y_train, epochs=10, batch_size=32):
        """
        Trains the LSTM model using the provided training data.
        
        :param X_train: The input features for training.
        :param y_train: The target values for training.
        :param epochs: Number of epochs to train for (default: 10).
        :param batch_size: Size of the batch used during training (default: 32).
        """
        try:
            # Scaling the input and target data
            X_train_scaled = self.scaler.fit_transform(X_train.reshape(-1, X_train.shape[2])).reshape(X_train.shape)
            y_train_scaled = self.output_scaler.fit_transform(y_train)
            
            # Define a learning rate reduction callback
            lr_callback = ReduceLROnPlateau(monitor='loss', factor=0.2, patience=5, min_lr=0.0001)
            
            # Train the model with the scaled data and specified parameters
            self.model.fit(X_train_scaled, y_train_scaled, epochs=epochs, batch_size=batch_size, verbose=1, callbacks=[lr_callback])
        except Exception as e:
            logging.error(f"Error during training: {e}")  # Log any error that occurs during training
            raise  # Reraise the exception

    def predict(self, X):
        """
        Makes predictions on the input data using the trained LSTM model.
        
        :param X: The input data for prediction.
        :return: The predicted values (inverse scaled back to the original range).
        """
        # Check if the input data has the expected number of features
        expected_features = len([col for col in self.scaler.data_max_])
        if X.shape[2] != expected_features:
            raise ValueError(f"Expected input with {expected_features} features, got {X.shape[2]} features")
        
        # Scale the input data and make predictions
        X_scaled = self.scaler.transform(X.reshape(-1, X.shape[2])).reshape(X.shape)
        predictions_scaled = self.model.predict(X_scaled)
        
        # Inverse scale the predictions to get them back to the original range
        predictions = self.output_scaler.inverse_transform(predictions_scaled)
        return predictions

    def save_model(self, model_path):
        """
        Saves the trained model, input scaler, and output scaler to disk.
        
        :param model_path: The path where the model and scalers should be saved.
        """
        # Save the model in Keras format
        self.model.save(f'{model_path}.keras')
        
        # Save the scalers using joblib
        joblib.dump(self.scaler, f'{model_path}_scaler.pkl')
        joblib.dump(self.output_scaler, f'{model_path}_output_scaler.pkl')

    def load_model(self, model_path):
        """
        Loads a pre-trained model and its associated scalers from disk.
        
        :param model_path: The path where the model and scalers are saved.
        """
        # Load the model in Keras format
        self.model = load_model(f'{model_path}.keras')
        
        # Load the scalers using joblib
        self.scaler = joblib.load(f'{model_path}_scaler.pkl')
        self.output_scaler = joblib.load(f'{model_path}_output_scaler.pkl')
        
        # Compile the model after loading it (necessary if model has been saved without compiling)
        self.model.compile(optimizer=self.optimizer, loss=self.loss)

    def evaluate(self, X_test, y_test):
        """
        Evaluates the model on the test data and calculates the Root Mean Squared Error (RMSE).
        
        :param X_test: The input test data.
        :param y_test: The target values for the test data.
        :return: The RMSE value.
        """
        try:
            # Ensure the input data has three dimensions
            if X_test.ndim == 2:
                X_test = X_test.reshape((X_test.shape[0], X_test.shape[1], 1))
            
            # Check if the input features match the expected number
            expected_features = len([col for col in self.scaler.data_max_])
            if X_test.shape[2] != expected_features:
                raise ValueError(f"Expected input with {expected_features} features, got {X_test.shape[2]} features")
            
            # Scale the test data
            X_test_scaled = self.scaler.transform(X_test.reshape(-1, X_test.shape[2])).reshape(X_test.shape)
            y_test_scaled = self.output_scaler.transform(y_test)
            
            # Make predictions
            predictions_scaled = self.model.predict(X_test_scaled)
            predictions = self.output_scaler.inverse_transform(predictions_scaled)
            
            # Calculate the RMSE (Root Mean Squared Error) between predictions and actual values
            RMSE=np.sqrt(np.mean((predictions_scaled - y_test_scaled) ** 2))
            rmse = np.sqrt(np.mean((predictions - y_test) ** 2))
            return rmse
        except Exception as e:
            logging.error(f"Error in evaluate method: {e}")  # Log error if evaluation fails
            raise  # Reraise the exception
