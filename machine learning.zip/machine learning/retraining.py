import logging  # For logging messages like info, warnings, and errors
import numpy as np  # For numerical operations and array manipulations

# Class responsible for retraining the model with new historical data
class ModelRetrainer:
    # Constructor to initialize the retrainer with model, MT5 interface, and configuration
    def __init__(self, model, mt5, config, df):
        self.model = model  # The LSTM model that will be retrained
        self.mt5 = mt5  # Interface for interacting with MetaTrader 5 to fetch data
        self.config = config  # Configuration settings, such as paths, symbols, and other parameters
        self.df = df  # DataFrame with historical data
    # Method to retrain the model and save it
    def retrain_and_save_model(self, df, n_steps):
        try:
            # Check if historical data was successfully fetched
            if df is None or df.empty:
                logging.error("Failed to fetch historical data for retraining.")
                return

            if df is None or df.empty:
                logging.error("No data to calculate changes.")
                return

            X_train = []  # List to store input sequences for training
            y_train = []  # List to store target values for training

            # Create input and output sequences from historical data using technical indicators
            for i in range(len(df) - n_steps):
                # dff=df.drop(columns=['close_change']) 
                indicators = df.iloc[i:i+n_steps][[col for col in df.columns ]].values
                X_train.append(indicators)  # Append 'n_steps' indicators as input
                y_train.append(df['close_change'].iloc[i+n_steps])  # Append the 'n_steps+1' close change as output

            # Convert the input and output lists to NumPy arrays
            X_train = np.array(X_train).reshape(-1, n_steps, len(indicators[0]))  # Reshape to (samples, timesteps, features)
            y_train = np.array(y_train).reshape(-1, 1)  # Reshape to (samples, 1)

            # Recreate the optimizer instance
            self.model.create_model((n_steps, len(indicators[0])))
            
            # Fit the scaler on the input training data (flattened to 2D)
            self.model.scaler.fit(X_train.reshape(-1, X_train.shape[2]))

            # Train the model with the new data
            self.model.train(X_train, y_train, epochs=50, batch_size=1)
            
            # Log that the model was retrained successfully
            logging.info("Model retrained with new data.")
            
            # Save the retrained model to the specified path in the config
            self.model.save_model(self.config['model_path'])
            
            # Log that the model was saved successfully
            logging.info(f"Model saved successfully at {self.config['model_path']}")
        except Exception as e:
            # Log any errors that occur during the retraining process
            logging.error(f"Error during model retraining: {e}")
