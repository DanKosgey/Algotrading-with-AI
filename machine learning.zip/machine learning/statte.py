import time  # For sleep to control execution frequency in the trading loop
import logging  # For logging information and errors
import pandas as pd  # For data manipulation using DataFrames
from trend import Trend  # Import trend detection logic from custom trend module
from intface import MT5Interface  # Import MT5 interface for interaction with MetaTrader 5
from risk_management import RiskManagement  # Import the RiskManagement class
from place_order import PlaceOrder  # Import the PlaceOrder class
import MetaTrader5 as mt5  # MetaTrader 5 package for trading functionalities

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Class defining the trading strategy logic
class TradingStrategy:
    # Initialize the class with model and symbol parameters
    def __init__(self, model, symbol, df, config):
        self.model = model  # The trained LSTM model for price prediction
        self.symbol = symbol  # Forex symbol to trade on
        self.config = config  # Configuration parameter
        self.MT5 = MT5Interface(config)  # Initialize MT5 interface for trading functions with config
        self.df = df
        self.risk_manager = RiskManagement()  # Initialize RiskManagement class
        self.place_order = PlaceOrder(symbol)  # Initialize PlaceOrder with the symbol

    def generate_signal(self,timesteps, df: pd.DataFrame) -> str:
        # Validate the input DataFrame to ensure it is not empty or incorrectly formatted
        if not isinstance(df, pd.DataFrame) or df.empty:
            logging.error("Invalid data format or empty data for signal generation")  # Log the error
            return 'hold'  # Return 'hold' if data is invalid

        try:
            # Use trend detection logic from the Trend class
            trend = Trend.get_trend(self.symbol)  # Get the trend for the symbol
        except Exception as e:
            logging.error(f"Error detecting trend: {e}")  # Log any error during trend detection
            return 'hold'  # Return 'hold' if there is a trend detection issue

        try:
            # Prepare input data for the model (using the last 15 technical indicators)
            input_data = df[[col for col in df.columns]].tail(15).values
            input_data = input_data.reshape((1,timesteps, input_data.shape[1]))  # Reshape data for LSTM input format (batch_size, timesteps, features)
            # Get the model's scaled prediction
            prediction = self.model.predict(input_data)
            # Log the predictions
            logging.info(f"Detected trend: {trend}")
            logging.info(f"Model prediction (change in close price): {prediction}")

        except KeyError as e:
            logging.error(f"Error generating signal: {e}")
            return 'hold'
        except ValueError as e:
            logging.error(f"Error generating signal: {e}")
            return 'hold'

        # Decision-making based on trend and predicted change in close price
        if trend == 'uptrend' and prediction > 4:  # Buy signal if uptrend and predicted change > 0.5
            logging.info("Buy signal generated")
            return 'buy'
        elif trend == 'downtrend' and prediction < -4:  # Sell signal if downtrend and predicted change < -0.5
            logging.info("Sell signal generated")
            return 'sell'
        else:
            logging.info("Hold signal generated")  # Hold if conditions aren't met
            return 'hold'

    def run(self):
        while True:
            try:
                if not self.df.empty:  # If data was fetched successfully
                    signal = self.generate_signal(self.df)  # Generate trading signal
                    # Execute trade based on signal
                    self.place_order.execute_trade(signal)
                    
                    # Calculate and log risk
                    risk_percentage = self.place_order.calculate_risk()
                    logging.info(f"Current risk percentage: {risk_percentage}")

                    # Evaluate the model's prediction accuracy (RMSE) using the most recent data
                    X_test = self.df[[col for col in self.df.columns]].values[-15:].reshape((1, 15, self.df.shape[1]))
                    y_test = self.df['close_change'].values[-1:].reshape((1, 1))
                    rmse = self.model.evaluate(X_test, y_test)  # Calculate root mean squared error (RMSE)
                    logging.info(f"RMSE: {rmse}")

                    # Log that the trading loop is continuing
                    logging.info("Continuing trading loop...")
                    time.sleep(60)  # Adjust sleep time as necessary for your strategy
            except Exception as e:
                logging.error(f"Error in strategy run: {e}")  # Log any errors that occur in the loop

if __name__ == "__main__":
    # This script is intended to be imported and used by another script (main.py)
    pass
