import MetaTrader5 as mt5  # Importing MetaTrader5 (MT5) package to interact with the trading platform.
import pandas as pd  # Importing pandas for data manipulation, particularly for handling and processing financial data.
import logging  # Importing logging to log errors, info, and debug messages during the execution of the bot.

# Configure logging to capture logs with INFO level or higher, and to display the timestamp, log level, and message.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Defining the RiskManagement class to manage open trades and apply risk management strategies.
class RiskManagement:
    # Method to manage open account positions.
    def manage_account(self):
        # Get all open positions (orders) from the MT5 account.
        open_orders = mt5.positions_get()

        # If there are no open positions, log an error and return.
        if open_orders is None:
            logging.error(f"No positions found, error code: {mt5.last_error()}")  # Log an error message with the error code.
            return
        
        # Iterate through each open order (position).
        for order in open_orders:
            # If the order does not have stop loss (SL) or take profit (TP) set, check and update them.
            if order.sl == 0.0 or order.tp == 0.0:
                self.check_order(order)
            # Call trailing_stop() to update the stop loss dynamically for the order.
            self.trailing_stop(order)

    # Method to check and update the stop loss (SL) and take profit (TP) of an order.
    def check_order(self, order):
        symbol = order.symbol  # Get the symbol (currency pair or asset) of the order.
        order_price = order.price_open  # Get the open price of the order (price at which the order was executed).
        
        # Calculate the Average True Range (ATR) to determine dynamic stop loss and take profit levels.
        atr = self.calculate_atr(symbol)

        # Calculate the stop loss (SL) and take profit (TP) based on the ATR value:
        # If the order is a buy, set SL as order price - 2x ATR, TP as order price + 3x ATR.
        # If the order is a sell, set SL as order price + 2x ATR, TP as order price - 3x ATR.
        stop_loss = order_price - (atr * 2) if order.type == mt5.ORDER_TYPE_BUY else order_price + (atr * 2)
        take_profit = order_price + (atr * 3) if order.type == mt5.ORDER_TYPE_BUY else order_price - (atr * 3)

        # Prepare the request dictionary for updating the order's SL and TP.
        request = {
            "action": mt5.TRADE_ACTION_SLTP,  # Action type: updating SL/TP.
            "position": order.ticket,  # Order ticket (unique identifier for the order).
            "sl": stop_loss,  # Stop loss level.
            "tp": take_profit  # Take profit level.
        }

        # Send the request to MetaTrader5 to update the order's stop loss and take profit.
        result = mt5.order_send(request)

        # Check the result of the order update:
        if result is None:
            logging.error(f"Order update failed: result is None for order {order.ticket}")  # Log error if the result is None.
        elif result.retcode != mt5.TRADE_RETCODE_DONE:
            logging.error(f"Failed to update order {order.ticket}, error code: {result.retcode}")  # Log error if the update fails.
        else:
            # If the order was successfully updated, log the new SL and TP values.
            logging.info(f"Updated order {order.ticket} with SL={stop_loss}, TP={take_profit}")

    # Method to dynamically adjust the stop loss (trailing stop) for an open order.
    def trailing_stop(self, order):
        symbol = order.symbol  # Get the symbol (currency pair or asset) of the order.
        
        # Get the current price (bid price for buy orders, ask price for sell orders) from MT5.
        current_price = mt5.symbol_info_tick(symbol)
        if not current_price:
            logging.error(f"Failed to get current price for {symbol}")  # Log error if current price is unavailable.
            return
        
        # Determine the current price based on order type (buy or sell).
        price = current_price.bid if order.type == mt5.ORDER_TYPE_BUY else current_price.ask

        # Calculate the ATR to adjust the stop loss dynamically based on volatility.
        atr = self.calculate_atr(symbol)

        # Calculate the new stop loss level using ATR:
        # For buy orders, new stop loss = current price - 2x ATR.
        # For sell orders, new stop loss = current price + 2x ATR.
        new_stop_loss = price - (atr * 2) if order.type == mt5.ORDER_TYPE_BUY else price + (atr * 2)

        # Check if the new stop loss is better (more favorable) than the current one:
        # For buy orders, we want the new stop loss to be higher than the previous one.
        # For sell orders, we want the new stop loss to be lower than the previous one.
        if (order.type == mt5.ORDER_TYPE_BUY and new_stop_loss > order.sl) or (order.type == mt5.ORDER_TYPE_SELL and new_stop_loss < order.sl):
            # Prepare the request to update the stop loss.
            request = {
                "action": mt5.TRADE_ACTION_SLTP,  # Action type: updating SL/TP.
                "position": order.ticket,  # Order ticket (unique identifier).
                "sl": new_stop_loss,  # New stop loss level.
                "tp": order.tp  # Keep the original take profit level.
            }

            # Send the update request to MT5.
            result = mt5.order_send(request)

            # Check the result of the trailing stop update:
            if result is None:
                logging.error(f"Trailing stop update failed: result is None for order {order.ticket}")  # Log error if the result is None.
            elif result.retcode != mt5.TRADE_RETCODE_DONE:
                logging.error(f"Failed to update trailing stop for order {order.ticket}, error code: {result.retcode}")  # Log error if the update fails.
            else:
                # If the trailing stop was successfully updated, log the new stop loss level.
                logging.info(f"Trailing stop for order {order.ticket} updated to SL={new_stop_loss}")

    # Method to calculate the Average True Range (ATR) for a given symbol.
    def calculate_atr(self, symbol, period=14):
        # Get the historical price data (candles) for the symbol using MT5, here using the M5 timeframe and 100 bars.
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M5, 0, 100)

        # Convert the raw rates data into a pandas DataFrame for easier manipulation.
        df = pd.DataFrame(rates)

        # Calculate the True Range (TR) for each candle:
        df['tr1'] = df['high'] - df['low']  # TR1: High - Low
        df['tr2'] = abs(df['high'] - df['close'].shift())  # TR2: Absolute value of (High - Previous Close)
        df['tr3'] = abs(df['low'] - df['close'].shift())  # TR3: Absolute value of (Low - Previous Close)

        # The True Range (TR) is the maximum of TR1, TR2, and TR3 for each candle.
        df['tr'] = df[['tr1', 'tr2', 'tr3']].max(axis=1)

        # Calculate the ATR (Average True Range) by taking the rolling mean of the True Range over the specified period (default is 14).
        df['atr'] = df['tr'].rolling(window=period).mean()

        # Return the latest ATR value (last value in the ATR column).
        return df['atr'].iloc[-1]
