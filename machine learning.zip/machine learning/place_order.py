import MetaTrader5 as mt5
import logging
import pandas as pd
import json

# Load configuration from JSON file
with open(r'C:\Users\HP\Desktop\machine learning\logins.json', 'r') as file:
    config = json.load(file)

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class PlaceOrder:
    def __init__(self, symbol):
        self.symbol = symbol  # Add the symbol attribute

    def initialize_mt5(self):
        if not mt5.initialize(path=config['mt5Pathway']):
            logging.error("Failed to initialize MT5")
            return False
        if not mt5.login(login=config['username'], password=config['password'], server=config['server']):
            logging.error("Failed to log in to MT5")
            return False
        logging.info("MT5 initialized and logged in")
        return True

    def calculate_risk(self):
        open_orders = mt5.positions_get()
        if open_orders is None:
            logging.error(f"No positions found, error code: {mt5.last_error()}")
            return 0
        total_risk = 0
        for order in open_orders:
            order_price = order.price_open
            stop_loss = order.sl
            volume = order.volume
            point = mt5.symbol_info(order.symbol).point
            if stop_loss <= 0:
                logging.warning(f"Stop loss not set for order {order.ticket}")
                continue
            if order.type == mt5.ORDER_TYPE_BUY:
                risk = (order_price - stop_loss) * volume / point
            else:
                risk = (stop_loss - order_price) * volume / point
            total_risk += abs(risk)
        account_info = mt5.account_info()
        if account_info is None:
            logging.error(f"Failed to get account info, error code: {mt5.last_error()}")
            return 0
        total_risk_percentage = total_risk / account_info.equity * 100
        return total_risk_percentage

    def place_order(self, symbol, volume, order_type, atr_multiplier=1.5):
        current_risk = self.calculate_risk()
        if current_risk >= 0.1:  # Assuming risk threshold is 2%
            logging.info("Risk threshold exceeded, no new orders will be placed.")
            return False
        # Check if symbol information is available
        symbol_info = mt5.symbol_info(symbol)
        if symbol_info is None:
            logging.error(f"Symbol info not found for {symbol}")
            return False
        # Ensure the symbol is visible
        if not symbol_info.visible:
            if not mt5.symbol_select(symbol, True):
                logging.error(f"Failed to select symbol {symbol}")
                return False
        price = mt5.symbol_info_tick(symbol)
        if price is None:
            logging.error(f"Failed to get price for {symbol}")
            return False
        atr = self.calculate_atr(symbol)
        stop_loss = price.ask - (atr * atr_multiplier) if order_type == "BUY_STOP" else price.bid + (atr * atr_multiplier)
        take_profit = price.ask + (atr * (atr_multiplier * 2)) if order_type == "BUY_STOP" else price.bid - (atr * (atr_multiplier * 2))

        point = symbol_info.point  # Get the point value for the symbol

        if order_type == "SELL_STOP":
            order_type_mt5 = mt5.ORDER_TYPE_SELL_STOP
            price_order = round(price.bid - 30* point, 5)  # Example: 10 points below the bid
        elif order_type == "BUY_STOP":
            order_type_mt5 = mt5.ORDER_TYPE_BUY_STOP
            price_order = round(price.ask + 30 * point, 5)  # Example: 10 points above the ask
        else:
            logging.error("Invalid order type")
            return False

        request = {
            "action": mt5.TRADE_ACTION_PENDING,
            "symbol": symbol,
            "volume": volume,
            "type": order_type_mt5,
            "price": price_order,
            "sl": stop_loss,
            "tp": take_profit,
            "type_filling": mt5.ORDER_FILLING_RETURN,
            "type_time": mt5.ORDER_TIME_GTC,
            "comment": "Python order"
        }
        logging.info(f"Placing order: {request}")
        result = mt5.order_send(request)
        if result is None:
            logging.error("Order send failed: result is None")
            return False
        elif result.retcode != mt5.TRADE_RETCODE_DONE:
            logging.error(f"Failed to place order, error code: {result.retcode}")
            return False
        else:
            logging.info("Order placed successfully!")
            return True

    def calculate_atr(self, symbol, period=14):
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M15, 0, 96)
        df = pd.DataFrame(rates)
        df['tr1'] = df['high'] - df['low']
        df['tr2'] = abs(df['high'] - df['close'].shift())
        df['tr3'] = abs(df['low'] - df['close'].shift())
        df['tr'] = df[['tr1', 'tr2', 'tr3']].max(axis=1)
        df['atr'] = df['tr'].rolling(window=period).mean()
        return df['atr'].iloc[-1]

    # Method to execute trades based on the signal
    def execute_trade(self, signal: str):
        if signal == 'hold':
            logging.info("Hold signal received. No action taken.")
            return
        
        if not self.initialize_mt5():
            return

        try:
            volume = 0.01  # Example trade volume
            if signal == 'buy':
                if self.place_order(self.symbol, volume, "BUY_STOP"):
                    logging.info("Buy stop order executed")
                else:
                    logging.error("Buy stop order failed")
            elif signal == 'sell':
                if self.place_order(self.symbol, volume, "SELL_STOP"):
                    logging.info("Sell stop order executed")
                else:
                    logging.error("Sell stop order failed")
        except Exception as e:
            logging.error(f"Error executing trade: {e}")  # Log any errors during trade execution

if __name__ == "__main__":
    # Test PlaceOrder class functionality here if needed
    pass
