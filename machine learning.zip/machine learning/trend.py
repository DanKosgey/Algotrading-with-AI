import pandas as pd
import logging
import MetaTrader5 as mt5
import ta

class Trend:
    
    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.df = self.calculate_indicators(df)

    @staticmethod
    def calculate_indicators(df: pd.DataFrame):
        try:
            df['SMA_Short'] = ta.trend.SMAIndicator(df['close'], window=5).sma_indicator()
            df['SMA_Long'] = ta.trend.SMAIndicator(df['close'], window=15).sma_indicator()
            df['EMA_Short'] = ta.trend.EMAIndicator(df['close'], window=7).ema_indicator()
            df['EMA_Long'] = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator()
            df['RSI'] = ta.momentum.RSIIndicator(df['close'], window=14).rsi()
            
            df.ffill(inplace=True)
            df.dropna(inplace=True)
            df.sort_index(inplace=True)

            return df

        except Exception as e:
            logging.error(f"Error calculating indicators: {e}")
            raise

    @staticmethod
    def get_trend(symbol: str):
        try:
            rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M15, 0, 50)
            df = pd.DataFrame(rates)
            
            if df.empty:
                logging.error(f"No data fetched for {symbol}")
                return "error"
            
            df = Trend.calculate_indicators(df)
            sma_short = df['SMA_Short'].iloc[-1]
            sma_long = df['SMA_Long'].iloc[-1]
            ema_short = df['EMA_Short'].iloc[-1]
            ema_long = df['EMA_Long'].iloc[-1]
            rsi_value = df['RSI'].iloc[-1]

            is_uptrend = sma_short > sma_long and ema_short > ema_long and rsi_value > 40
            is_downtrend = sma_short < sma_long and ema_short < ema_long and rsi_value < 60

            if is_uptrend:
                return "uptrend"
            elif is_downtrend:
                return "downtrend"
            else:
                return "sideways"
                
        except Exception as e:
            logging.error(f"Error getting trend for {symbol}: {e}")
            return "error"
